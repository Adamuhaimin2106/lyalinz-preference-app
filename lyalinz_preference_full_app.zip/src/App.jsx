import React from "react";
import WhoDoYouPreferApp from "./WhoDoYouPreferApp";

function App() {
  return <WhoDoYouPreferApp />;
}

export default App;