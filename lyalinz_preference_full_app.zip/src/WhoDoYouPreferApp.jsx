import React, { useState } from "react";

const names = [
  "Khalisah", "Hanis", "Syarifah", "Syakirah", "Imanina", "Hana", "Syaurah", "Ailin", "Khadijah", "Maryam Z.",
  "Yumna Y.", "Alya Q.", "Ayaka", "Qis", "Aishah Sofea", "Aisyah Solehah", "Juwita", "Syifa' Syafiqah", "Cahaya", "Syifa Rifhani", "Farisya",
  "Yumna Ar-rumy", "Eva", "Huda", "Husna", "Amani", "Dhia Maisarah", "Dhia Amni", "Shifa O.", "Nuha", "Marsya", "Maryam S."
];

export default function WhoDoYouPreferApp() {
  const [currentIndex, setCurrentIndex] = useState(1);
  const [champion, setChampion] = useState(names[0]);
  const [history, setHistory] = useState([]);

  const handleChoose = (choice) => {
    const winner = choice === "A" ? champion : names[currentIndex];
    setHistory([...history, { round: currentIndex, A: champion, B: names[currentIndex], winner }]);
    setChampion(winner);
    setCurrentIndex(currentIndex + 1);
  };

  if (currentIndex >= names.length) {
    return (
      <div className="center">
        <h1>🏆 Your Final Pick:</h1>
        <h2 style={{ color: '#4ade80' }}>{champion}</h2>
        <div className="card">
          <p>Your Decision History:</p>
          <ul>
            {history.map((h, i) => (
              <li key={i}>
                Round {h.round}: {h.A} vs {h.B} → <strong>{h.winner}</strong>
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  }

  return (
    <div className="center">
      <h1>Who Do You Prefer? (Lyalinz Gamer Edition)</h1>
      <div className="card">
        <p>Choose between:</p>
        <button onClick={() => handleChoose("A")} className="blue">{champion}</button>
        <p>vs</p>
        <button onClick={() => handleChoose("B")} className="green">{names[currentIndex]}</button>
        <p>Match {currentIndex} of {names.length - 1}</p>
      </div>
    </div>
  );
}